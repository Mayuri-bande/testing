plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.uimodel"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.uimodel"
        minSdk = 21
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    implementation(libs.appcompat)
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)

    // Unit testing dependencies
    testImplementation(libs.junit)
    testImplementation(libs.ext.junit)
    testImplementation(libs.espresso.core)

    // UI Testing
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)

    // LiveData testing support
    testImplementation("androidx.arch.core:core-testing:2.2.0")
}
