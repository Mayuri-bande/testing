package com.example.uimodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class LoginViewModel extends ViewModel {

    private final MutableLiveData<Boolean> loginSuccess = new MutableLiveData<>();

    public LiveData<Boolean> getLoginSuccess() {
        return loginSuccess;
    }

    // Simple validation logic
    public void login(String username, String password) {
        if ("admin".equals(username) && "1234".equals(password)) {
            loginSuccess.setValue(true);
        } else {
            loginSuccess.setValue(false);
        }
    }
}
