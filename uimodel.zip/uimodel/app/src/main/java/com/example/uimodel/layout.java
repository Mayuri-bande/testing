package com.example.uimodel;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class layout extends AppCompatActivity {

    private LoginViewModel viewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layout); // Make sure you have this layout XML

        EditText etUsername = findViewById(R.id.etUsername);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        TextView tvResult = findViewById(R.id.tvResult);

        viewModel = new ViewModelProvider(this).get(LoginViewModel.class);

        // ✅ Observe login result (updated to match ViewModel method)
        viewModel.getLoginSuccess().observe(this, success -> {
            if (success) {
                tvResult.setText("Login Successful");
            } else {
                tvResult.setText("Login Failed");
            }
        });

        // ✅ Trigger login
        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString();
            String password = etPassword.getText().toString();
            viewModel.login(username, password);
        });
    }
}
