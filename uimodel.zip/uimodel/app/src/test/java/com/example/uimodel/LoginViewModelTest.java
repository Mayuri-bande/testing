package com.example.uimodel;

import static org.junit.Assert.*;

import androidx.arch.core.executor.testing.InstantTaskExecutorRule;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;

public class LoginViewModelTest {

    @Rule
    public InstantTaskExecutorRule instantExecutorRule = new InstantTaskExecutorRule();

    private LoginViewModel viewModel;

    @Before
    public void setup() {
        viewModel = new LoginViewModel();
    }

    @Test
    public void login_withCorrectCredentials_returnsTrue() {
        viewModel.login("admin", "1234");
        Boolean result = viewModel.getLoginSuccess().getValue();
        assertNotNull(result);
        assertTrue(result);
    }

    @Test
    public void login_withWrongCredentials_returnsFalse() {
        viewModel.login("user", "wrong");
        Boolean result = viewModel.getLoginSuccess().getValue();
        assertNotNull(result);
        assertFalse(result);
    }
}
