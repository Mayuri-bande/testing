package com.example.uimodel;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.*;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.*;

@RunWith(AndroidJUnit4.class)
public class layoutTest {

    @Rule
    public ActivityScenarioRule<layout> activityRule =
            new ActivityScenarioRule<>(layout.class);

    @Test
    public void login_withValidCredentials_showsSuccess() {
        // Type "admin" in username field and close keyboard
        onView(withId(R.id.etUsername)).perform(typeText("admin"), closeSoftKeyboard());
        // Type "1234" in password field and close keyboard
        onView(withId(R.id.etPassword)).perform(typeText("1234"), closeSoftKeyboard());
        // Click the login button
        onView(withId(R.id.btnLogin)).perform(click());
        // Check if the result TextView shows "Login Successful"
        onView(withId(R.id.tvResult)).check(matches(withText("Login Successful")));
    }

    @Test
    public void login_withInvalidCredentials_showsFailure() {
        onView(withId(R.id.etUsername)).perform(typeText("user"), closeSoftKeyboard());
        onView(withId(R.id.etPassword)).perform(typeText("wrong"), closeSoftKeyboard());
        onView(withId(R.id.btnLogin)).perform(click());
        onView(withId(R.id.tvResult)).check(matches(withText("Login Failed")));
    }
}
